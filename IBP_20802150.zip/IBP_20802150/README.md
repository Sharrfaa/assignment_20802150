# Student name: Durgahed Bibi Sharfaa
# Student id: 20802150
#
# Code details:
#
# First we run the wget command for downloading enron email data.
# Import the necessary libraries: sqlite3, pandas, matplotlib.pyplot and seaborn
# Create a cursor object
# Writing SQL queries and executing them as well as storing the results in dataframes
# Check the schema of tables for employeelist, message, recipientinfo and referenceinfo.
# Convert data to dataframe and display the dataframe
# Plotting line graph using subplots(), lineplot(), plt.title() and plt.show()
# Creating a figure and axes for the plot, plotting the line using seaborn
# Setting a title for the graph and displaying the graph
# Plot bar chart using barplot(), plt.title() and plt.show()
# Setting the data for the bar plot
# Creating a bar plot using seaborn
# Setting the title of the bar chart and displaying the plot
# Plotting pie chart
# Commit the changes to the database and lastly closing the database connection.
